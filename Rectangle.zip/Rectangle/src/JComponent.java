
public class JComponent {

}
