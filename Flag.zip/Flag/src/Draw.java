public class Draw {
 
    public static void main(String[] args) {
 
        new Fun();
 
    }
 
}