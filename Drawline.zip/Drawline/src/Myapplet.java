

import java.awt.*;
public class Myapplet {
	
	public void paint(Graphics g)
	
	{
		g.drawLine(20, 20, 100, 20);
	}

}
