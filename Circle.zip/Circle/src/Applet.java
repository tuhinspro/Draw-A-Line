
public class Applet {

}
