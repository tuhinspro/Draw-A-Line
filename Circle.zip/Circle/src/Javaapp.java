import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;

public class Javaapp extends Applet {
	
	 public void paint(Graphics g) {
	       
	        g.setColor(Color.RED);
	        g.fillOval(20, 20, 100, 100);

   }
	 
}
