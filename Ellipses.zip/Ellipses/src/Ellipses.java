import java.awt.*;
import java.applet.*;

public class Ellipses extends Applet {
	
	public void paint(Graphics g)
    {
            
       g.drawOval(40,30,90,30);
            
    }

}
